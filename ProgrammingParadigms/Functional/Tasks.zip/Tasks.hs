{-
	PP Project 2021

	This is where you will write the implementation for the given tasks.
	You can add other modules aswell.
-}

module Tasks where

import Dataset
import Text.Printf
import Data.List 

type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]

{-
	TASK SET 1
-}

--- Functie care ma ajuta la un read fara eroare la ""
--- Converteste String la Float 

better_read :: String -> Float
better_read "" = 0.0
better_read string = read string :: Float

-- Task 1

compute_exam_grades :: Table -> Table
compute_exam_grades (x:xs) = ["Nume","Punctaj Exam"] : functieAjutatoare_pt_restul_listei xs

functieAjutatoare_pt_restul_listei [] = []
functieAjutatoare_pt_restul_listei (x:xs) = ((head x):[(printf "%.2f" (sum (map (\elem -> better_read elem ) ((tail.init) x)) / 4 + (better_read (last x) )))]) : (functieAjutatoare_pt_restul_listei xs)

-- Task 2
-- Number of students who have passed the exam:

get_passed_students_num :: Table -> Int
get_passed_students_num [] = 0                                                                     -- cazul de baza 
get_passed_students_num (x:xs) = length $ functieAjutatoare_2 (tail $ compute_exam_grades (x:xs)) -- folosind length , aflam studentii care au trecut examenul 
                            
functieAjutatoare_2 [] = []
functieAjutatoare_2 (x:xs) = if (better_read (last x) ) >= 2.5 then x : functieAjutatoare_2 xs else functieAjutatoare_2 xs

-- Percentage of students who have passed the exam:

-- Realizam impartirea studentilor care au trecut la toti studentii 

get_passed_students_percentage :: Table -> Float
get_passed_students_percentage xs = (fromIntegral (get_passed_students_num xs) :: Float )/(fromIntegral ((length xs) - 1) :: Float)

-- Average exam grade

-- Realizam media examenului , facand suma tututor rezultatelor la numarul acestor 
get_exam_avg :: Table -> Float
get_exam_avg (x:xs) = total_sum_notes (tail $ compute_exam_grades (x:xs) ) / (fromIntegral ((length xs) ) :: Float ) 

-- Functia ajutatoare care ma ajuta sa fac suma notelor din examen 

total_sum_notes [] = 0.0
total_sum_notes (head:tail) = (( better_read (last head) ) + (total_sum_notes tail))

-- Number of students who gained at least 1.5p from homework:

get_passed_hw_num :: Table -> Int
get_passed_hw_num [] = 0
get_passed_hw_num  (x:xs) = length $ get_hw_sum xs -- Folosind length , aflam cati studenti au trecut de punctajul pe tem a

--- Functie ajutatoare care ma ajuta sa fac suma rezultatelor din tema 

get_hw_sum [] = []
get_hw_sum (x:xs) = if (( (better_read ((x) !! 2)) + (better_read ((x) !! 3)) + (better_read ((x) !! 4)) )) >= 1.5  then (x : get_hw_sum xs) else (get_hw_sum xs) 
 
-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs [] = []
get_avg_responses_per_qs (x:xs) = ["Q1","Q2","Q3","Q4","Q5","Q6"] : [( map (printf "%.2f") (avg_qs_response ((tail.init) (tr xs))))]

--- Folosind aceasta functie aflam media pe fiecare intrebare 
avg_qs_response :: Table -> [Float]
avg_qs_response [] = []
avg_qs_response (x:xs) = ((total_sum_notes_2 x) / (fromIntegral (length x) :: Float )) : (avg_qs_response xs)
 
total_sum_notes_2 :: [String] -> Float
total_sum_notes_2 [] = 0.0
total_sum_notes_2 (head:tail) = (( better_read ( head) ) + (total_sum_notes_2 tail))

--- Functie care realizeaza transpusa 

tr :: [[a]] -> [[a]]
tr ([]:_) = []
tr m  = (map head m):(tr (map tail m))

-- Task 4

--- Functie care ma ajuta sa stiu cate intrebari de 0 , 1 si 2 sunt pe o coloana
howmany_of_a_type :: Row -> Row
howmany_of_a_type lista_intrebari = map show $ [length (filter (\x -> x == "0" || x == "") (lista_intrebari)), length (filter ( == "1") (lista_intrebari)), length (filter ( == "2") (lista_intrebari))]

get_exam_summary :: Table -> Table
get_exam_summary (x:xs) = ["Q","0","1","2"] : zipWith (:) ["Q1","Q2","Q3","Q4","Q5","Q6"] (map  howmany_of_a_type ((tail.init) (tr xs)) ) 

-- Task 5
get_ranking :: Table -> Table
get_ranking table  = ["Nume","Punctaj Exam"]: sortBy compares_two_students (tail (compute_exam_grades table) )

--- Functie care compara doua stringuri alfabetic 
compares_two_names :: Row -> Row -> Ordering
compares_two_names s1 s2
    | (head s1) > (head s2)  = GT
    | (head s1) < (head s2) = LT
    | otherwise = LT

--- Functie care compara notele a doi studenti 
compares_two_students :: Row -> Row -> Ordering
compares_two_students nota_1 nota_2 
    | (better_read (last nota_1)) > (better_read (last nota_2))   = GT
    | (better_read (last nota_1)) < (better_read (last nota_2))  = LT
    | otherwise = compares_two_names nota_1 nota_2

-- Task 6

get_exam_diff_table :: Table -> Table
get_exam_diff_table (x:xs)  = ["Nume","Punctaj interviu","Punctaj scris","Diferenta"] : sortBy compares_two_students (tr $ (map head xs) : (map (\l_elem -> printf "%.2f" ((sum (map (\elem -> better_read elem ) ((tail.init) l_elem ))) / 4 )) xs ) : ( map ((printf "%.2f").better_read.last) xs ) : [ map difference  xs ] )
                                                     
-- Diferenta in modul dintre puctajul din interviu si cel din examenul scris 

difference x = printf "%.2f" (abs ((sum (map (\elem -> better_read elem ) ((tail.init) x)) / 4) - (better_read (last x) )))