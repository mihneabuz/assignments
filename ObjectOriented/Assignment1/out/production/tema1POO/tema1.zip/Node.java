class Node {
    final private int DEFAULT_MAX_SIZE = 20;
    final int index;
    final private Road[] roads;
    private int size;
    final private int max_size;

    public Node() {
        this.index = -1;
        this.max_size = DEFAULT_MAX_SIZE;
        this.size = 0;
        this.roads = new Road[this.max_size];
    }

    public Node(int max_size, int index) {
        this.index = index;
        this.max_size = max_size;
        this.size = 0;
        this.roads = new Road[this.max_size];
    }

    public Road getRoad(int index) {
        if (index > this.size)
            return null;
        return this.roads[index];
    }

    public int getSize() {
        return this.size;
    }

    public void print() { //for debugging
        for (int i = 0; i < this.size; i++) {
            this.roads[i].print();
        }
    }

    public void addRoad(Node dest, int cost, int limit) {
        this.roads[size] = new Road(this, dest, cost, limit);
        this.size ++;
    }

}