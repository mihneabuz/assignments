public class Car extends Vehicle{
    public Car() {
        super();
        limit = 2;
        cost = 4;
    }
}

