public class Vehicle {
    protected int limit;
    protected int cost;

    public Vehicle() {
    }

    static Vehicle newVehicle(char c) {
        Vehicle aux = null;
        if (c == 'b') {
            aux = new Bicycle();
        }
        else if (c == 'm') {
            aux = new Motorbike();
        }
        else if (c == 'a') {
            aux = new Car();
        }
        else if (c == 'c') {
            aux = new Truck();
        }
        return aux;
    }

    public int getLimit() {
        return limit;
    }

    public int getCost() {
        return cost;
    }
}
