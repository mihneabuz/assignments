public class Graph {

    final private int MAX_ROAD_SIZE = 30;
    final private int DEFAULT_SIZE = 20;
    final private int size;
    final private Node[] nodes;

    public Graph() {
        this.size = DEFAULT_SIZE;
        this.nodes = new Node[this.size + 1];
        for (int i = 0; i < this.size; i++) {
            this.nodes[i] = new Node(MAX_ROAD_SIZE, i);
        }
    }

    public Graph(int size) {
        this.size = size;
        this.nodes = new Node[this.size + 1];
        for (int i = 0; i < this.size; i++) {
            this.nodes[i] = new Node(MAX_ROAD_SIZE, i);
        }
    }

    public void print() { //for debugging
        for (int i = 0; i < this.size; i++) {
            this.nodes[i].print();
        }
    }

    public void addStreet(int start, int end, int cost, int size) {
        this.nodes[start].addRoad(this.nodes[end], cost, size);
    }

    public void addRestriction(String type, int start, int end, int cost) {
        Node src = this.nodes[start];
        Restriction restr = new Restriction(type, cost);
        for (int i = 0; i < src.getSize(); i++) {
            if (src.getRoad(i).getDest() == end) {
                src.getRoad(i).restrict(restr);
            }
        }
    }

    private void backtrack(int[] prev_index, int cur, StringBuffer rez) {
        //reconstruieste drumul cel mai scurt si il scrie in rez
        if (!(cur == prev_index[cur])) {
            backtrack(prev_index, prev_index[cur], rez);
        }
        rez.append("P" + cur + " ");
    }

    public String drive(Vehicle veh, int start, int end) {
        int[] costs = new int[this.size + 1];
        int[] prev_index = new int[this.size + 1];
        for (int i = 0; i < this.size; i++)
            costs[i] = Integer.MAX_VALUE;
        costs[start] = 0;
        prev_index[start] = start;

        PriorityQueue q = new PriorityQueue(this.size);
        q.push(start, 0);

        while(!q.isEmpty()) {
            q.updateQueue();
            Node aux = this.nodes[q.pop()];
            for (int i = 0; i < aux.getSize(); i ++) {
                if (aux.getRoad(i).canDrive(veh)) {
                    int cur = costs[aux.index] + aux.getRoad(i).computeCost(veh);
                    if (costs[aux.getRoad(i).getDest()] > cur) {
                        q.push(aux.getRoad(i).getDest(), cur);
                        costs[aux.getRoad(i).getDest()] = cur;
                        prev_index[aux.getRoad(i).getDest()] = aux.index;
                    }
                }
            }
        }

        StringBuffer path = new StringBuffer();
        if (costs[end] == Integer.MAX_VALUE)
            path.append("P" + start + " " + "P" + end + " null");
        else {
            backtrack(prev_index, end, path);
            path.append(costs[end]);
        }
        return path.toString();
    }
}
