public class Bicycle extends Vehicle{
    public Bicycle() {
        super();
        limit = 1;
        cost = 1;
    }
}
