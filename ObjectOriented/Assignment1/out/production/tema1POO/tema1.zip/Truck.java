public class Truck extends Vehicle{
    public Truck() {
        super();
        limit = 3;
        cost = 6;
    }
}

