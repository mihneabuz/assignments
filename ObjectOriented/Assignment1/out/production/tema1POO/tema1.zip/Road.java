class Road {
    final private Node src;
    final private Node dest;
    final private int cost;
    private int cost_environmental;
    final private int limit;

    public Road() {
        this.src = null;
        this.dest = null;
        this.cost = 0;
        this.limit = 0;
    }

    public Road(Node src, Node dest, int cost, int limit) {
        this.src = src;
        this.dest = dest;
        this.cost = cost;
        this.limit = limit;
        this.cost_environmental = 0;
    }

    public boolean canDrive(Vehicle veh) {
        if (veh.getLimit() > this.limit)
            return false;
        return true;
    }

    public int computeCost(Vehicle veh) {
        return (this.cost * veh.getCost()) + this.cost_environmental;
    }

    public void restrict(Restriction restr) {
        this.cost_environmental += restr.getCost();
    }

    public int getDest() {
        if (this.dest == null)
            return -1;
        return this.dest.index;
    }

    public int getSource() {
        if (this.src == null)
            return -1;
        return this.src.index;
    }

    public void print() {
        System.out.println(this.src.index + " " + this.dest.index + " " +
                this.cost + " " + this.cost_environmental + " " +this.limit);
    }
}