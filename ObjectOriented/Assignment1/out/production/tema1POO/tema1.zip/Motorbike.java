public class Motorbike extends Vehicle{
    public Motorbike() {
        super();
        limit = 1;
        cost = 2;
    }
}

