public class PriorityQueue {
    final static private int DEFAULT_MAX_SIZE = 1000;
    final private int max_size;
    private int size;
    final private int[] elem;
    final private int[] priority;

    public PriorityQueue(int max_size) {
        this.max_size = max_size;
        this.size = 0;
        elem = new int[max_size + 1];
        priority = new int[max_size + 1];
    }

    public PriorityQueue() {
        this.max_size = DEFAULT_MAX_SIZE;
        this.size = 0;
        elem = new int[max_size + 1];
        priority = new int[max_size + 1];
    }

    private int parent(int pos) {
        return pos / 2;
    }

    private void swap(int pos1, int pos2)
    {
        int tmp;
        tmp = elem[pos1];
        elem[pos1] = elem[pos2];
        elem[pos2] = tmp;
        tmp = priority[pos1];
        priority[pos1] = priority[pos2];
        priority[pos2] = tmp;
    }

    public boolean isEmpty() {
        if (this.size == 0)
            return true;
        return false;
    }

    private void updatePriority(int elem, int value) {
        for (int i = 1; i <= this.size; i++) {
            if (this.elem[i] == elem)
                this.priority[i] = value;
        }
    }

    public boolean hasElem(int elem) {
        for (int i = 1; i <= this.size; i++) {
            if (this.elem[i] == elem)
                return true;
        }
        return false;
    }

    public void updateQueue() {
        int k;
        for (int i = 2; i <= this.size; i++) {
            k = i;
            while (this.priority[k] < this.priority[parent(k)]) {
                this.swap(k, parent(k));
                k = parent(k);
            }
        }
    }

    public void print() {
        if (this.isEmpty())
            System.out.println("Queue is empty.");
        else
            for (int i = 1; i <= this.size; i ++) {
                System.out.println(this.priority[i]);
            }
    }

    public void push(int index, int priority) {
        if (this.hasElem(index))
            this.updatePriority(index, priority);
        else {
            this.size++;
            this.elem[this.size] = index;
            this.priority[this.size] = priority;
        }
    }

    public int pop() {
        if (this.isEmpty()) {
            System.out.println("Queue is empty.");
            return 0;
        }
        int popped = this.elem[1];
        this.swap(1, this.size);
        this.size--;
        return popped;
    }
}
